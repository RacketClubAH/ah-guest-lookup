# Aphrodite Hills Racket Club – Guest Lookup

A static browser application intended for GitHub Pages. It reads a Protel HMS **Inhouse Board List** PDF in the browser and replaces the contents of one SharePoint list with the extracted current guest rooms.

## What it does

- Sign in with a hotel Microsoft work account using Microsoft Entra ID (MSAL).
- Search guest surnames and room codes.
- Read the PDF locally in the browser with PDF.js; the PDF is not uploaded to GitHub or another server by this app.
- Preview extracted records before publishing.
- Check the extracted row count against the report's `Total Rooms` figure where present.
- Replace the SharePoint guest list only after validation and confirmation.
- Keep guest details in SharePoint. The browser holds the loaded list in memory only; only non-secret connection identifiers are stored in local browser storage.

## Important security and deployment notes

1. Do not add a Rentals PDF, guest export, screenshot of guest data, or real guest names to this GitHub repository.
2. GitHub Pages websites are publicly reachable. The page source is not private just because the repository is private. The guest list is protected separately by Microsoft sign-in and SharePoint permissions.
3. Obtain hotel IT / data-protection approval before using real guest information. GitHub Pages also logs visitors' IP addresses as part of its service. GitHub says Pages is not intended as free hosting for an online business or a site primarily facilitating commercial transactions; because this tool supports a shop-discount check, treat this as a prototype until hotel IT/management approves the hosting choice. An approved internal host may be required for production.
4. This is a static front end only. It has no server-side secret. It uses Microsoft Entra delegated sign-in and Microsoft Graph.
5. The app is configured for the least-privilege Graph pattern `Lists.SelectedOperations.Selected`, with a separate explicit **write** grant to the one `Current Guests` list. An administrator must consent to the scope and assign the app to the list. Microsoft documents that the selected scope alone grants no list access until the resource permission is also assigned.
6. PDF extraction is designed for the text-based Protel HMS Inhouse Board List layout supplied during development. It is not OCR. A scanned/image-only PDF will not parse. The app blocks publishing if the extracted row count does not match `Total Rooms` or if required values are missing.

## Files

- `index.html` – page layout
- `styles.css` – interface styling
- `app.js` – PDF parsing, Microsoft sign-in and SharePoint list operations

## Part A — Create the SharePoint list

Create a SharePoint **List** named `Current Guests` in a site approved by hotel IT.

Keep the default `Title` column (the app fills it with the guest name). Add these columns with the exact internal names:

| Column | Type | Required |
|---|---|---|
| `GuestName` | Single line of text | Yes |
| `Room` | Single line of text | Yes |
| `PropertyType` | Single line of text | Yes |
| `ArrivalDate` | Date and time, Date only | Yes |
| `DepartureDate` | Date and time, Date only | Yes |
| `ReportDate` | Date and time, Date only | Yes |

Do not rename the internal names of the added columns. Avoid adding required columns that the app does not populate. The app fills both `Title` and `GuestName` with the guest name. This is also compatible with the earlier Excel starter workbook, which already contains the `GuestName` column.

The list should be accessible only to the appropriate reception staff and approved administrators. The app replaces the list's contents at each daily import, so use a dedicated list and do not store unrelated records in it.

## Part B — Publish on GitHub Pages

1. Download/extract this project.
2. Create a GitHub repository named `ah-guest-lookup`.
3. Upload **only** `index.html`, `styles.css`, `app.js`, and this `README.md` to the repository root. Never upload guest PDF files or real guest data.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then Save.
7. Wait for the Pages deployment to finish. Open the Pages URL from Settings → Pages.
8. Copy that exact URL and ask IT to register it as the SPA redirect URI in Part B.

GitHub Free requires the Pages source repository to be public. GitHub Pro/Team/Enterprise plans may support Pages from private repositories, but the published website may still be public depending on the plan and Pages visibility controls. Never treat repository privacy as guest-data protection.


## Part C — Microsoft Entra app registration (IT / administrator step)

The app uses the delegated Microsoft Graph scope `Lists.SelectedOperations.Selected`.

1. In the Microsoft Entra admin center, create an app registration named `Aphrodite Hills Guest Lookup`.
2. Choose **Accounts in this organizational directory only**.
3. Under **Authentication**, add a **Single-page application (SPA)** redirect URI. Use the exact GitHub Pages URL shown in the app's Settings panel after publishing, for example `https://YOUR-USERNAME.github.io/ah-guest-lookup/`.
4. Under **API permissions**, add **Microsoft Graph → Delegated permissions → `Lists.SelectedOperations.Selected`**.
5. Grant admin consent for that delegated permission.
6. Grant this app the **write** role on the one `Current Guests` list. Microsoft documents the list permission endpoint as `POST /sites/{siteId}/lists/{listId}/permissions`. The administrator can do this with Microsoft Graph tooling and an account with the necessary permissions. Use the application (client) ID from the app registration. Example request body shape:

```json
{
  "grantedToV2": {
    "application": {
      "id": "YOUR-APPLICATION-CLIENT-ID",
      "displayName": "Aphrodite Hills Guest Lookup"
    }
  },
  "roles": ["write"]
}
```

7. Give the app owner these four non-secret identifiers:
   - Directory (tenant) ID
   - Application (client) ID
   - SharePoint Site ID
   - `Current Guests` List ID

The `Site ID` and `List ID` are IDs from Microsoft Graph, not the SharePoint site's display name. An administrator can retrieve them using Microsoft Graph Explorer (one-time lookup):

   - `GET https://graph.microsoft.com/v1.0/sites/{sharepoint-hostname}:/sites/{site-path}?$select=id`
   - Then `GET https://graph.microsoft.com/v1.0/sites/{site-id}/lists?$select=id,displayName` and copy the ID for `Current Guests`.

The Graph Explorer account needs permission to read the site/list metadata for this lookup. That one-time lookup permission does not need to be added to the guest lookup app. Do not give the app broad `Sites.ReadWrite.All` access just to avoid looking up these IDs; the selected-list permission is the intended scope for this project.

## Part D — Configure both reception computers

On each reception computer:

1. Open the GitHub Pages URL in Edge or Chrome.
2. Open **Settings**.
3. Enter the Tenant ID, Client ID, Site ID and List ID supplied by IT.
4. Select **Save settings**.
5. Select **Sign in** and use your hotel Microsoft account.
6. Once the SharePoint list loads, search a test surname. Do not upload live reports until IT has approved the app and staff access.

Settings are saved in that browser only, so repeat this once on the second computer. Guest records are fetched from SharePoint after sign-in.

## Daily reception use

1. Open the app and sign in if required.
2. Select the morning Protel PDF.
3. Click **Read PDF**.
4. Check the report date, number of rooms, validation message and preview.
5. Only when the preview says **Ready to publish**, click **Publish latest list**.
6. The previous list is replaced. Both reception computers see the updated list after refresh/reload.

The status means **listed in the latest uploaded report**. It does not prove that a person is physically present at the resort.

## Test before live use

Use a redacted copy or a non-production test list first. For the supplied sample report, the parser is intended to identify 72 room rows across two pages and handle the wrapped guest name rows near rooms `AT12` and `UJ03`. Check those rows manually against the PDF preview. Different Protel report layouts may need parser adjustments.

## Troubleshooting

- **AADSTS / consent error:** IT has not consented to `Lists.SelectedOperations.Selected`, or the user has not been granted access to the list.
- **403 Forbidden:** Check the app's explicit `write` assignment on the correct list and the signed-in user's SharePoint access.
- **404 Not found:** Check the Site ID and List ID supplied in Settings.
- **Redirect URI mismatch:** Register the exact URL shown in the app's Settings panel as a SPA redirect URI.
- **No rows / wrong room count:** The PDF may be scanned or have a different Protel layout. Do not publish. Use a text-based Protel report and have the parser adjusted against a redacted sample.
- **MSAL or PDF.js CDN blocked:** Ask IT whether the network allows the required library CDN endpoints. The app currently loads pinned library modules from jsDelivr.

## Microsoft / GitHub references

- Microsoft Graph selected permissions for SharePoint and OneDrive: https://learn.microsoft.com/graph/permissions-selected-overview
- Microsoft Entra single-page app registration: https://learn.microsoft.com/entra/identity-platform/scenario-spa-app-registration
- Microsoft Graph create a list item: https://learn.microsoft.com/graph/api/listitem-create
- GitHub Pages quickstart: https://docs.github.com/en/pages/quickstart
- GitHub Pages site visibility and creation: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
