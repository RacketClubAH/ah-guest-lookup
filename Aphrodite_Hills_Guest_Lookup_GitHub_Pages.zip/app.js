import { PublicClientApplication, InteractionRequiredAuthError } from "https://cdn.jsdelivr.net/npm/@azure/msal-browser@5.29.0/+esm";
import * as pdfjsLib from "https://cdn.jsdelivr.net/npm/pdfjs-dist@6.5.438/build/pdf.min.mjs";

const GRAPH_ROOT = "https://graph.microsoft.com/v1.0";
const GRAPH_SCOPES = ["Lists.SelectedOperations.Selected"];
const PDFJS_VERSION = "6.5.438";
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_VERSION}/build/pdf.worker.min.mjs`;

const $ = (id) => document.getElementById(id);
const CONFIG_KEY = "ahGuestLookupConfigV1";
let config = readConfig();
let msalApp = null;
let account = null;
let accessToken = null;
let currentGuests = [];
let pendingImport = null;
let toastTimer = null;

function readConfig() {
  try { return JSON.parse(localStorage.getItem(CONFIG_KEY) || "{}"); }
  catch { return {}; }
}
function saveConfigToStorage(value) {
  localStorage.setItem(CONFIG_KEY, JSON.stringify(value));
  config = value;
}
function hasConfig() {
  return ["tenantId", "clientId", "siteId", "listId"].every(k => String(config[k] || "").trim());
}
function redirectUri() {
  const u = new URL(window.location.href);
  u.search = ""; u.hash = "";
  return u.toString();
}
function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 4200);
}
function showNotice(message, type = "neutral") {
  const el = $("parseStatus");
  el.className = `notice notice-${type}`;
  el.textContent = message;
  el.classList.remove("hidden");
}
function hideNotice() { $("parseStatus").classList.add("hidden"); }
function setPill(text, state) {
  const el = $("connectionPill");
  el.textContent = text;
  el.className = `status-pill ${state}`;
}
function formatDate(value) {
  if (!value) return "—";
  const d = new Date(`${String(value).slice(0, 10)}T12:00:00`);
  if (Number.isNaN(d.getTime())) return String(value);
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(d);
}
function isoDate(date) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function updateControls() {
  const ready = hasConfig();
  $("signInButton").disabled = !ready || Boolean(account);
  $("signOutButton").classList.toggle("hidden", !account);
  $("searchInput").disabled = !account;
  // Local PDF parsing is allowed before sign-in; publishing still requires an authenticated SharePoint session.
  $("pdfInput").disabled = false;
  $("parseButton").disabled = !$("pdfInput").files?.length;
  if (!ready) setPill("Settings needed", "status-warn");
  else if (account) setPill("Microsoft connected", "status-online");
  else setPill("Ready to sign in", "status-offline");
}
function fillSettings() {
  $("tenantIdInput").value = config.tenantId || "";
  $("clientIdInput").value = config.clientId || "";
  $("siteIdInput").value = config.siteId || "";
  $("listIdInput").value = config.listId || "";
  $("redirectUriText").textContent = redirectUri();
}
function msalConfiguration() {
  return {
    auth: {
      clientId: config.clientId.trim(),
      authority: `https://login.microsoftonline.com/${config.tenantId.trim()}`,
      redirectUri: redirectUri(),
      navigateToLoginRequestUrl: false
    },
    cache: { cacheLocation: "sessionStorage", storeAuthStateInCookie: false },
    system: { loggerOptions: { loggerCallback: () => {}, piiLoggingEnabled: false } }
  };
}
async function ensureMsal() {
  if (!hasConfig()) throw new Error("Complete the Microsoft connection settings first.");
  if (!msalApp) {
    msalApp = new PublicClientApplication(msalConfiguration());
    await msalApp.initialize();
    const accounts = msalApp.getAllAccounts();
    if (accounts.length) {
      account = accounts[0];
      msalApp.setActiveAccount(account);
    }
  }
  return msalApp;
}
async function signIn() {
  try {
    const app = await ensureMsal();
    if (!account) {
      const result = await app.loginPopup({ scopes: GRAPH_SCOPES, prompt: "select_account" });
      account = result.account;
      app.setActiveAccount(account);
    }
    updateControls();
    await loadGuests();
    showToast("Microsoft account connected.");
  } catch (error) {
    console.error(error);
    showToast(readableError(error));
    setPill("Connection failed", "status-bad");
  }
}
async function signOut() {
  try {
    const app = await ensureMsal();
    if (account) await app.logoutPopup({ account });
  } catch (error) { console.warn(error); }
  account = null; accessToken = null; currentGuests = [];
  $("searchInput").value = "";
  renderSearch();
  updateControls();
  $("reportDateLabel").textContent = "Not loaded";
  $("reportCountLabel").textContent = "Sign in to load guests";
}
async function getToken() {
  const app = await ensureMsal();
  account = account || app.getActiveAccount() || app.getAllAccounts()[0];
  if (!account) throw new Error("Please sign in to Microsoft first.");
  try {
    const result = await app.acquireTokenSilent({ scopes: GRAPH_SCOPES, account });
    accessToken = result.accessToken;
    return accessToken;
  } catch (error) {
    if (error instanceof InteractionRequiredAuthError || error?.name === "InteractionRequiredAuthError") {
      const result = await app.acquireTokenPopup({ scopes: GRAPH_SCOPES, account });
      accessToken = result.accessToken;
      return accessToken;
    }
    throw error;
  }
}
function safeGraphId(id) {
  return encodeURIComponent(String(id).trim()).replaceAll("%2C", ",");
}
async function graphRequest(pathOrUrl, options = {}) {
  const token = await getToken();
  const url = pathOrUrl.startsWith("http") ? pathOrUrl : `${GRAPH_ROOT}${pathOrUrl}`;
  const headers = new Headers(options.headers || {});
  headers.set("Authorization", `Bearer ${token}`);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  let response;
  for (let attempt = 0; attempt < 4; attempt++) {
    response = await fetch(url, { ...options, headers });
    if (response.status !== 429 && response.status !== 503) break;
    const wait = Number(response.headers.get("Retry-After") || 2 ** attempt);
    await new Promise(resolve => setTimeout(resolve, Math.min(wait, 12) * 1000));
  }
  if (!response.ok) {
    let detail = "";
    try { const body = await response.json(); detail = body?.error?.message || JSON.stringify(body); }
    catch { detail = response.statusText; }
    const err = new Error(`Microsoft Graph ${response.status}: ${detail}`);
    err.status = response.status;
    throw err;
  }
  if (response.status === 204) return null;
  return response.json();
}
function listItemsPath() {
  return `/sites/${safeGraphId(config.siteId)}/lists/${safeGraphId(config.listId)}/items`;
}
async function getAllListItems() {
  let url = `${GRAPH_ROOT}${listItemsPath()}?$expand=fields&$top=999`;
  const all = [];
  while (url) {
    const page = await graphRequest(url);
    all.push(...(page.value || []));
    url = page["@odata.nextLink"] || null;
  }
  return all;
}
function graphFieldRecord(item) {
  const f = item.fields || {};
  return {
    id: item.id,
    guestName: f.GuestName || f.Title || "",
    room: f.Room || "",
    propertyType: f.PropertyType || "",
    arrivalDate: String(f.ArrivalDate || "").slice(0, 10),
    departureDate: String(f.DepartureDate || "").slice(0, 10),
    reportDate: String(f.ReportDate || "").slice(0, 10)
  };
}
async function loadGuests() {
  if (!account) throw new Error("Sign in first.");
  $("emptyState").classList.add("hidden");
  $("reportCountLabel").textContent = "Loading guest list…";
  try {
    const items = await getAllListItems();
    currentGuests = items.map(graphFieldRecord).filter(r => r.guestName && r.room);
    const reportDate = currentGuests.map(r => r.reportDate).filter(Boolean).sort().at(-1);
    $("reportDateLabel").textContent = reportDate ? formatDate(reportDate) : "No report";
    $("reportCountLabel").textContent = `${currentGuests.length} guest rooms loaded`;
    $("searchInput").disabled = false;
    renderSearch();
  } catch (error) {
    console.error(error);
    $("reportCountLabel").textContent = "Could not load SharePoint list";
    showToast(readableError(error));
    throw error;
  }
}
function renderSearch() {
  const query = $("searchInput").value.trim().toLocaleLowerCase();
  const area = $("resultList");
  area.replaceChildren();
  if (!account) {
    $("emptyState").classList.remove("hidden");
    $("resultSummary").classList.add("hidden");
    return;
  }
  if (currentGuests.length === 0) {
    $("emptyState").classList.remove("hidden");
    $("emptyState").querySelector("h3").textContent = "No guest report imported yet";
    $("emptyState").querySelector("p").textContent = "Upload the latest Protel Rentals PDF below to populate the Current Guests list.";
    $("resultSummary").classList.add("hidden");
    return;
  }
  $("emptyState").classList.add("hidden");
  if (!query) {
    $("resultSummary").classList.remove("hidden");
    $("resultSummary").textContent = `${currentGuests.length} rooms in the latest uploaded report. Start typing to search.`;
    return;
  }
  const matches = currentGuests.filter(r =>
    r.guestName.toLocaleLowerCase().includes(query) || r.room.toLocaleLowerCase().includes(query)
  ).sort((a, b) => a.guestName.localeCompare(b.guestName));
  $("resultSummary").classList.remove("hidden");
  $("resultSummary").textContent = matches.length
    ? `${matches.length} matching room${matches.length === 1 ? "" : "s"} · Listed in the latest Rentals report`
    : `No match for “${$("searchInput").value.trim()}” in the latest Rentals report`;
  if (!matches.length) {
    const card = document.createElement("div");
    card.className = "empty-state panel";
    card.innerHTML = `<div class="empty-icon">×</div><h3>Not found in latest report</h3><p>This name or room does not appear in the most recently imported Rentals list.</p>`;
    area.append(card);
    return;
  }
  for (const r of matches) {
    const card = document.createElement("article");
    card.className = "guest-card";
    card.innerHTML = `
      <div class="guest-main"><div class="guest-name">${escapeHtml(r.guestName)}</div><div class="guest-meta">Listed in current Rentals report</div></div>
      <div class="guest-details">
        <div class="detail"><span>Room</span><strong>${escapeHtml(r.room)}</strong></div>
        <div class="detail"><span>Property</span><strong>${escapeHtml(r.propertyType || "—")}</strong></div>
        <div class="detail"><span>Arrival</span><strong>${escapeHtml(formatDate(r.arrivalDate))}</strong></div>
        <div class="detail"><span>Departure</span><strong>${escapeHtml(formatDate(r.departureDate))}</strong></div>
      </div>
      <span class="status-pill status-good">Listed in-house</span>`;
    area.append(card);
  }
}

function groupItemsIntoLines(items) {
  const clean = items.filter(i => i.str && i.str.trim()).map(i => ({
    text: i.str.trim(), x: Number(i.transform?.[4] || 0), y: Number(i.transform?.[5] || 0)
  })).sort((a, b) => b.y - a.y || a.x - b.x);
  const lines = [];
  for (const item of clean) {
    let line = lines.find(l => Math.abs(l.y - item.y) <= 1.8);
    if (!line) { line = { y: item.y, items: [] }; lines.push(line); }
    line.items.push(item);
  }
  for (const line of lines) line.items.sort((a, b) => a.x - b.x);
  return lines.sort((a, b) => b.y - a.y);
}
function isRoomCode(value) { return /^(?=.*\d)[A-Z0-9]{3,6}$/i.test(value); }
const NON_NAME_TOKENS = new Set(["REP", "RR", "RB", "RF", "LV0", "VIP", "TERMS"]);
function lineRoom(line) {
  return line.items.find(i => i.x < 55 && isRoomCode(i.text));
}
function guestTokens(line) {
  return line.items.filter(i => i.x >= 140 && i.x < 245 && !NON_NAME_TOKENS.has(i.text.toUpperCase()));
}
function parseReportDate(allText) {
  const m = allText.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (!m) return null;
  return new Date(Date.UTC(Number(m[3]), Number(m[2]) - 1, Number(m[1])));
}
function inferArrivalDate(dayMonth, reportDate) {
  const [day, month] = dayMonth.split("/").map(Number);
  const candidates = [reportDate.getUTCFullYear() - 1, reportDate.getUTCFullYear(), reportDate.getUTCFullYear() + 1]
    .map(y => new Date(Date.UTC(y, month - 1, day)))
    .filter(d => d <= reportDate);
  return candidates.sort((a, b) => b - a)[0] || null;
}
function inferDepartureDate(dayMonth, arrivalDate) {
  const [day, month] = dayMonth.split("/").map(Number);
  const candidates = [arrivalDate.getUTCFullYear() - 1, arrivalDate.getUTCFullYear(), arrivalDate.getUTCFullYear() + 1]
    .map(y => new Date(Date.UTC(y, month - 1, day)))
    .filter(d => d >= arrivalDate);
  return candidates.sort((a, b) => a - b)[0] || null;
}
async function parseProtelPdf(file) {
  const data = new Uint8Array(await file.arrayBuffer());
  const pdf = await pdfjsLib.getDocument({ data }).promise;
  const pages = [];
  const allText = [];
  for (let pageNo = 1; pageNo <= pdf.numPages; pageNo++) {
    const page = await pdf.getPage(pageNo);
    const content = await page.getTextContent();
    allText.push(...content.items.map(i => i.str || ""));
    pages.push(groupItemsIntoLines(content.items));
  }
  const text = allText.join(" ");
  const reportDate = parseReportDate(text);
  const totalMatch = text.match(/Total\s+Rooms\s*:?\s*(\d+)/i);
  const expectedTotal = totalMatch ? Number(totalMatch[1]) : null;
  if (!reportDate) throw new Error("I could not find the report date (dd/mm/yyyy). Make sure this is the Protel Inhouse Board List PDF.");

  const rows = [];
  for (const lines of pages) {
    const roomLines = lines.map((line, index) => ({ line, index, roomItem: lineRoom(line) })).filter(x => x.roomItem);
    const pageRows = roomLines.map(entry => ({
      room: entry.roomItem.text.toUpperCase(),
      y: entry.line.y,
      sourceLine: entry.line,
      nameLines: [entry.line],
      propertyType: entry.line.items.find(i => i.x >= 55 && i.x < 140)?.text || ""
    }));
    // Protel sometimes wraps a guest name onto a nearby line above/below the room row.
    for (const line of lines) {
      if (lineRoom(line)) continue;
      const names = guestTokens(line);
      if (!names.length) continue;
      let best = null;
      for (const row of pageRows) {
        const distance = Math.abs(row.y - line.y);
        if (distance <= 10.5 && (!best || distance < best.distance)) best = { row, distance };
      }
      if (best) best.row.nameLines.push(line);
    }

    for (const row of pageRows) {
      const nameItems = row.nameLines.flatMap(line => guestTokens(line).map(i => ({ ...i, y: line.y })))
        .sort((a, b) => b.y - a.y || a.x - b.x);
      const guestName = nameItems.map(i => i.text).join(" ").replace(/\s+/g, " ").trim();
      const dateItems = row.sourceLine.items
        .filter(i => i.x >= 490 && /^\d{1,2}\/\d{1,2}$/.test(i.text))
        .sort((a, b) => a.x - b.x);
      const arrivalText = dateItems[0]?.text;
      const departureText = dateItems[1]?.text;
      const arrival = arrivalText ? inferArrivalDate(arrivalText, reportDate) : null;
      const departure = departureText && arrival ? inferDepartureDate(departureText, arrival) : null;
      rows.push({
        guestName,
        room: row.room,
        propertyType: row.propertyType,
        arrivalDate: arrival ? isoDate(arrival) : "",
        departureDate: departure ? isoDate(departure) : "",
        reportDate: isoDate(reportDate)
      });
    }
  }

  const errors = [];
  if (expectedTotal !== null && rows.length !== expectedTotal) {
    errors.push(`The PDF says ${expectedTotal} total rooms, but ${rows.length} rows were extracted.`);
  }
  for (const r of rows) {
    if (!r.guestName || !r.room || !r.propertyType || !r.arrivalDate || !r.departureDate) {
      errors.push(`Incomplete row: ${r.room || "unknown room"} (${r.guestName || "guest name missing"}).`);
    }
  }
  const rooms = rows.map(r => r.room);
  if (new Set(rooms).size !== rooms.length) errors.push("Duplicate room codes were detected in the extracted rows.");
  if (!rows.length) errors.push("No room rows were found. This may be a scanned PDF or a different report layout.");
  return { rows, reportDate: isoDate(reportDate), expectedTotal, errors, pageCount: pdf.numPages };
}
function renderPreview(result) {
  pendingImport = result;
  $("previewBlock").classList.remove("hidden");
  $("previewTitle").textContent = `Import preview · ${result.rows.length} rooms`;
  $("previewDetails").textContent = `Report date: ${formatDate(result.reportDate)} · ${result.pageCount} PDF page(s)`;
  const good = result.errors.length === 0 && (result.expectedTotal === null || result.expectedTotal === result.rows.length);
  $("validationPill").textContent = good ? "Ready to publish" : "Check required";
  $("validationPill").className = `status-pill ${good ? "status-good" : "status-bad"}`;
  const messages = $("validationMessages");
  messages.replaceChildren();
  if (good) {
    messages.textContent = result.expectedTotal === null
      ? "No total-room count was found in the PDF. Review the preview carefully before publishing."
      : `Validation passed: the PDF total (${result.expectedTotal}) matches the extracted rows.`;
  } else {
    for (const error of result.errors) {
      const p = document.createElement("div"); p.className = "error-line"; p.textContent = `• ${error}`; messages.append(p);
    }
  }
  const body = $("previewRows"); body.replaceChildren();
  for (const row of result.rows.slice(0, 12)) {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${escapeHtml(row.guestName)}</td><td>${escapeHtml(row.room)}</td><td>${escapeHtml(row.propertyType)}</td><td>${escapeHtml(formatDate(row.arrivalDate))}</td><td>${escapeHtml(formatDate(row.departureDate))}</td>`;
    body.append(tr);
  }
  if (result.rows.length > 12) {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td colspan="5" class="small-muted">Showing the first 12 of ${result.rows.length} extracted rows.</td>`;
    body.append(tr);
  }
  $("publishButton").disabled = !good || !account;
}
function setProgress(text, percent) {
  const container = $("parseStatus");
  container.className = "notice notice-neutral";
  container.innerHTML = `<div>${escapeHtml(text)}</div><div class="progress-track"><div class="progress-fill" style="width:${Math.max(0, Math.min(100, percent))}%"></div></div>`;
  container.classList.remove("hidden");
}
async function runPool(items, concurrency, fn, onProgress = () => {}) {
  let next = 0, done = 0;
  const workers = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      await fn(items[index], index);
      done++;
      onProgress(done, items.length);
    }
  });
  await Promise.all(workers);
}
function sharePointFields(record) {
  return {
    Title: record.guestName,
    GuestName: record.guestName,
    Room: record.room,
    PropertyType: record.propertyType,
    ArrivalDate: `${record.arrivalDate}T00:00:00Z`,
    DepartureDate: `${record.departureDate}T00:00:00Z`,
    ReportDate: `${record.reportDate}T00:00:00Z`
  };
}
async function deleteItems(items, progressLabel) {
  let done = 0;
  for (const item of items) {
    await graphRequest(`${listItemsPath()}/${encodeURIComponent(item.id)}`, { method: "DELETE" });
    done++;
    setProgress(`${progressLabel} ${done}/${items.length}`, (done / items.length) * 100);
  }
}
async function createItems(records, progressLabel) {
  const created = [];
  let done = 0;
  for (const record of records) {
    const item = await graphRequest(`${listItemsPath()}`, {
      method: "POST",
      body: JSON.stringify({ fields: sharePointFields(record) })
    });
    created.push(item);
    done++;
    setProgress(`${progressLabel} ${done}/${records.length}`, (done / records.length) * 100);
  }
  return created;
}
async function publishImport() {
  if (!pendingImport || pendingImport.errors.length) return;
  const yes = window.confirm(`Publish ${pendingImport.rows.length} guest rooms from the ${formatDate(pendingImport.reportDate)} report?\n\nThis replaces the previous list. Make sure the preview is correct.`);
  if (!yes) return;
  $("publishButton").disabled = true;
  $("parseButton").disabled = true;
  $("pdfInput").disabled = true;
  let oldRecords = [];
  let oldItems = [];
  let deleteStarted = false;
  try {
    setProgress("Reading the current SharePoint list…", 5);
    oldItems = await getAllListItems();
    oldRecords = oldItems.map(graphFieldRecord).filter(r => r.guestName && r.room);

    if (oldItems.length) {
      deleteStarted = true;
      try {
        await deleteItems(oldItems, "Replacing previous guest list…");
      } catch (deleteError) {
        // Restore only rows that were successfully deleted before the error.
        setProgress("A delete was interrupted. Checking and restoring the previous list…", 5);
        const remaining = await getAllListItems();
        const existingRooms = new Set(remaining.map(graphFieldRecord).map(r => r.room));
        const missingOld = oldRecords.filter(r => !existingRooms.has(r.room));
        if (missingOld.length) await createItems(missingOld, "Restoring previous guest list…");
        throw deleteError;
      }
    }

    try {
      await createItems(pendingImport.rows, "Publishing new guest list…");
    } catch (writeError) {
      setProgress("Import interrupted. Restoring the previous guest list…", 5);
      try {
        const partial = await getAllListItems();
        if (partial.length) await deleteItems(partial, "Removing incomplete import…");
        if (oldRecords.length) await createItems(oldRecords, "Restoring previous guest list…");
      } catch (rollbackError) {
        console.error("Rollback failed", rollbackError);
        throw new Error(`${writeError.message} The automatic restore also failed. Contact your SharePoint administrator before using this list.`);
      }
      throw writeError;
    }
    await loadGuests();
    pendingImport = null;
    $("previewBlock").classList.add("hidden");
    $("fileName").textContent = "No file selected";
    $("pdfInput").value = "";
    showNotice(`Success: ${currentGuests.length} guest-room records published. The previous list has been replaced.`, "success");
    showToast("Latest Rentals report published successfully.");
  } catch (error) {
    console.error(error);
    showNotice(readableError(error), "error");
    showToast("Import was not completed. Check the message above.");
  } finally {
    $("publishButton").disabled = !pendingImport || Boolean(pendingImport?.errors?.length);
    $("parseButton").disabled = !$("pdfInput").files?.length;
    $("pdfInput").disabled = false;
  }
}
function readableError(error) {
  const text = error?.message || String(error);
  if (/AADSTS65001|consent_required|admin consent/i.test(text)) return "Microsoft administrator consent is still required for this app's SharePoint list permission.";
  if (/403|accessDenied|Forbidden/i.test(text)) return "Access denied. Ask the SharePoint administrator to grant this app write access to the Current Guests list and confirm that your account can edit the list.";
  if (/404|itemNotFound|Resource not found/i.test(text)) return "SharePoint Site ID or List ID was not found. Check the connection settings with your administrator.";
  if (/invalid_client|unauthorized_client/i.test(text)) return "Microsoft app registration or redirect URI is incorrect. Check the Client ID and registered GitHub Pages address.";
  if (/Failed to fetch|NetworkError/i.test(text)) return "Network request failed. Check your internet connection and whether the company network allows Microsoft Graph and the PDF.js CDN.";
  return text;
}

$("settingsButton").addEventListener("click", () => { fillSettings(); $("settingsPanel").classList.toggle("hidden"); });
$("closeSettingsButton").addEventListener("click", () => $("settingsPanel").classList.add("hidden"));
$("saveSettingsButton").addEventListener("click", async () => {
  const next = {
    tenantId: $("tenantIdInput").value.trim(),
    clientId: $("clientIdInput").value.trim(),
    siteId: $("siteIdInput").value.trim(),
    listId: $("listIdInput").value.trim()
  };
  if (Object.values(next).some(v => !v)) { showToast("Complete all four connection fields."); return; }
  saveConfigToStorage(next);
  msalApp = null; account = null; accessToken = null; currentGuests = [];
  updateControls();
  $("settingsPanel").classList.add("hidden");
  $("emptyState").classList.remove("hidden");
  $("emptyState").querySelector("h3").textContent = "Settings saved";
  $("emptyState").querySelector("p").textContent = "Sign in with your hotel Microsoft account to load the latest Rentals report.";
  showToast("Connection settings saved in this browser.");
});
$("resetSettingsButton").addEventListener("click", () => {
  if (!confirm("Clear the Microsoft connection settings from this browser?")) return;
  localStorage.removeItem(CONFIG_KEY); config = {}; msalApp = null; account = null; accessToken = null;
  fillSettings(); updateControls(); showToast("Settings cleared.");
});
$("copyRedirectButton").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(redirectUri()); showToast("Redirect URI copied."); }
  catch { showToast("Copy this address manually from the settings panel."); }
});
$("signInButton").addEventListener("click", signIn);
$("signOutButton").addEventListener("click", signOut);
$("searchInput").addEventListener("input", renderSearch);
$("clearSearchButton").addEventListener("click", () => { $("searchInput").value = ""; renderSearch(); $("searchInput").focus(); });
$("pdfInput").addEventListener("change", () => {
  const file = $("pdfInput").files?.[0];
  $("fileName").textContent = file ? file.name : "No file selected";
  $("parseButton").disabled = !file;
  $("previewBlock").classList.add("hidden"); pendingImport = null; hideNotice();
});
$("parseButton").addEventListener("click", async () => {
  const file = $("pdfInput").files?.[0];
  if (!file) return;
  if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) { showNotice("Please choose a PDF file.", "error"); return; }
  $("parseButton").disabled = true;
  showNotice("Reading the PDF locally in this browser…", "neutral");
  try {
    const result = await parseProtelPdf(file);
    renderPreview(result);
    if (result.errors.length) showNotice("The report did not pass validation. Do not publish it until the extraction is corrected.", "error");
    else showNotice("PDF read successfully. Review the preview before publishing.", "success");
  } catch (error) {
    console.error(error);
    showNotice(readableError(error), "error");
  } finally {
    $("parseButton").disabled = !$("pdfInput").files?.length;
  }
});
$("publishButton").addEventListener("click", publishImport);

fillSettings();
updateControls();
if (!hasConfig()) $("settingsPanel").classList.remove("hidden");
